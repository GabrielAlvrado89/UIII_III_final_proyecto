from django.contrib import admin
from .models import ventas

# Register your models here.
admin.site.register(ventas)